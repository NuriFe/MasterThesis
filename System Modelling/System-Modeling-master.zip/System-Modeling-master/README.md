# System-Modelling
This folder contains the codes necessary to create a model of a paralyzed arm controlled by FES

In any new folder you create, please create a README which explains the files in the folder(s).

This repository should be used to store codes, README's, and any other files related for modelling the arm controlled by FES. 

Data files from experiments should NOT be stored on GitHub and should instead use the lab OneDrive.



